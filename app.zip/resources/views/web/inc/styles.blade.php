<link rel="stylesheet" href="{{asset('frontend/style/style.css')}}">
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<script src="https://kit.fontawesome.com/fd479ff4ae.js" crossorigin="anonymous"></script>
{{-- @stack('styles') --}}