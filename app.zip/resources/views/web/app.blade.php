@include('web.layouts.head')
@include('web.layouts.navbar')
@yield('content')

@include('web.layouts.footer')