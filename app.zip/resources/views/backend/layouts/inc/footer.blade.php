

    @include('backend.layouts.inc.scripts')
</body>
</html>