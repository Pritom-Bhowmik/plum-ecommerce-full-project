


<?php $__env->startPush('styles'); ?>
    
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<section id="hero" style="background-image: url('<?php echo e(asset('frontend/img/backgrounds/'.$home_page->thumbnail)); ?>');">
    <h4>Summer collection</h4>
    <h2><?php echo e($home_page->page_title); ?></h2>
    <!--<h1> ALL Dresses!</h1>-->
    <p> <?php echo e($home_page->page_description); ?> </p>
     <a href="<?php echo e(route('web.shop')); ?>"><button>Shop Now</button></a>

  </section>

  <section id="feature" class="section-p1">
    <?php $__currentLoopData = $home_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="fe-box">
      <img src="<?php echo e(asset('frontend/img/category/'.$row->image)); ?>" alt="">
      <h6> <?php echo e($row->name); ?></h6>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </section>

  <section id="product1" class="section-p1">
    <h2> New</h2>
    <p>Summer collection</p>
    <div class="pro-container">
        <?php $__currentLoopData = \App\Models\Service::orderBy('id', 'desc')->get()->take(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="pro">
            <a href="<?php echo e(route('web.shop.details', ['id' => $row->id])); ?>">
                <img src="<?php echo e(asset('frontend/img/product/'.$row->image)); ?>" alt="">
                <div class="des">
                    <span> <?php echo e($row->category); ?> </span>
                    <h5><?php echo e($row->title); ?></h5>
                    <div class="star">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                    </div>
                    <h4> £<?php echo e($row->price); ?></h4>
                </div>
                <a href="<?php echo e(route('cart.add', $row->id)); ?>"><i class="fa fa-shopping-cart"></i></a>
            </a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

  </section>

<section id="banner" class="section-m1">
    <h4>Plum Membership</h4>
    <h2>UNLIMITED FREE NEXT DAY DELIVERY AND FREE RETURNS FOR ONLY<span>£15.99</span></h2>
  <button class="normal"> Explore More</button>
  </section>

  <section id="product1" class="section-p1">
    <h2> Dresses</h2>
    <p>Summer collection</p>
    <div class="pro-container">
        <?php $__currentLoopData = \App\Models\Service::where('category', 'Dresses')->get()->take(8); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="pro">
            <a href="<?php echo e(route('web.shop.details', ['id' => $row->id])); ?>">
                <img src="<?php echo e(asset('frontend/img/product/'.$row->image)); ?>" alt="">
                <div class="des">
                    <span> <?php echo e($row->category); ?> </span>
                    <h5><?php echo e($row->title); ?></h5>
                    <div class="star">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                    </div>
                    <h4> £<?php echo e($row->price); ?></h4>
                </div>
                <a href="<?php echo e(route('cart.add', $row->id)); ?>"><i class="fa fa-shopping-cart"></i></a>
            </a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

  </section>

  <section id="sm-banner" class="section-p1">
    <div class="banner-box">
      <h4>AMAZING discounts</h4>
      <h2> Buy now for 30% off all dresses</h2>
      <span> Featuring this summer's HOTTEST looks</span>
      <button class="white"> Explore Deals</button>
    </div>
    <div class="banner-box banner-box2">
      <h4>Style Inspo</h4>
      <h2> Summer trends</h2>
      <span> Solve your summer style dilemas</span>
      <button class="white"> Explore trends</button>
    </div>
  </section>

  <section id="banner3">
    <div class="banner-box">
      <h2>Season Sale</h2>
      <h3>30% Off</h3>
    </div>
    <div class="banner-box banner-box2">
      <h2>Dresses</h2>
      <h3>Summer Ready</h3>
    </div>
    <div class="banner-box banner-box3">
      <h2>Newe Collection</h2>
      <h3>Summer '23</h3>
    </div>
  </section>

<?php $__env->stopSection(); ?>
  
<?php $__env->startPush('scripts'); ?>
    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('web.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ptl4606q9941/public_html/web.au/resources/views/web/index.blade.php ENDPATH**/ ?>