<?php echo $__env->yieldPushContent('scripts_top'); ?>

<script>
    var resizefunc = [];
</script>

<script src="<?php echo e(asset('/backend/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('/backend/js/waves.js')); ?>"></script>
<script src="<?php echo e(asset('/backend/js/wow.min.js')); ?>"></script>
<script src="<?php echo e(asset('/backend/js/jquery.nicescroll.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('/backend/js/jquery.scrollTo.min.js')); ?>"></script>

<!-- sweet alerts -->
<script src="<?php echo e(asset('/backend/assets/sweet-alert/sweet-alert.min.js')); ?>"></script>
<script src="<?php echo e(asset('/backend/assets/sweet-alert/sweet-alert.init.js')); ?>"></script>

<!-- CUSTOM JS -->
<script src="<?php echo e(asset('/backend/js/jquery.app.js')); ?>"></script>


<script>

function ToastMessage(title="Success", message="Success", type="success"){
    $.Toast(title, message, type, {
        appendTo:"body",
        stack:false,
        position_class:"toast-top-right",
        fullscreen:false,
        width: 300,
        spacing: 20,
        timeout: 5000,
        has_close_btn:true,
        has_icon:true,
        sticky:false,
        border_radius: 3,
        has_progress:true,
        rtl:false
    })
}

</script>






<?php echo $__env->yieldPushContent('scripts'); ?>

<script src="<?php echo e(asset('/backend/assets/toast/toast.script.js')); ?>"></script>


<script type="text/javascript">


<?php if(session()->has('success')): ?>
    $.Toast("Success 👌","<?php echo e(session()->get('success')); ?>", "success", {
        appendTo:"body",
        stack:false,
        position_class:"toast-top-right",
        fullscreen:false,
        width: 300,
        spacing: 20,
        timeout: 5000,
        has_close_btn:true,
        has_icon:true,
        sticky:false,
        border_radius: 3,
        has_progress:true,
        rtl:false
    }
);
<?php endif; ?>

<?php if(session()->has('error')): ?>
    $.Toast("Error ⚠️","<?php echo e(session()->get('error')); ?>", "error", {
        appendTo:"body",
        stack:false,
        position_class:"toast-top-right",
        fullscreen:false,
        width: 300,
        spacing: 20,
        timeout: 5000,
        has_close_btn:true,
        has_icon:true,
        sticky:false,
        border_radius: 3,
        has_progress:true,
        rtl:false
    }
);
<?php endif; ?>

</script>
<?php /**PATH /home/ptl4606q9941/public_html/web.au/resources/views/backend/layouts/inc/scripts.blade.php ENDPATH**/ ?>