


<?php $__env->startSection('content'); ?>

<section id="blog">
    <?php $__currentLoopData = \App\Models\Blog::orderBy('id', 'desc')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="blog-box">
      <div class="blog-img">
        <img src="<?php echo e(asset('/frontend/img/blog/'.$row->thumbnail)); ?>" alt="">
        </div>
        <div class="blog details">
          <h4><?php echo e($row->title); ?></h4>
          <p><?php echo e($row->description); ?></p>
             <a href="#"> Continue Reading</a>
        </div>
        <h1> <?php echo e($row->created_at->format('d/m')); ?></h1>
      </div> 
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </section> 

  <!--<section id="pagination" class="section-p1">-->
  <!--  <a href="#">1</a>-->
  <!--  <a href="#">2</a>-->
  <!--  <a href="#"><i class="fas fa-long-arrow-alt-right"></i></a>-->
  <!--</section>-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ptl4606q9941/public_html/web.au/resources/views/web/blog.blade.php ENDPATH**/ ?>