<!DOCTYPE html>
<html lang="">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title> <?php echo $__env->yieldContent('title', 'Plum Ecommerce'); ?></title>
  <?php echo $__env->make('web.inc.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body><?php /**PATH /home/ptl4606q9941/public_html/web.au/resources/views/web/layouts/head.blade.php ENDPATH**/ ?>