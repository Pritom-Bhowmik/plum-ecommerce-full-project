<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="<?php echo e(asset('frontend/script/script.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
<script>
  <?php if(Session::has('message')): ?>
  toastr.options =
  {
  	"closeButton" : true,
  	"progressBar" : true
  }
  		toastr.success("<?php echo e(session('message')); ?>");
  <?php endif; ?>

  <?php if(Session::has('error')): ?>
  toastr.options =
  {
  	"closeButton" : true,
  	"progressBar" : true
  }
  		toastr.error("<?php echo e(session('error')); ?>");
  <?php endif; ?>

  <?php if(Session::has('info')): ?>
  toastr.options =
  {
  	"closeButton" : true,
  	"progressBar" : true
  }
  		toastr.info("<?php echo e(session('info')); ?>");
  <?php endif; ?>

  <?php if(Session::has('warning')): ?>
  toastr.options =
  {
  	"closeButton" : true,
  	"progressBar" : true
  }
  		toastr.warning("<?php echo e(session('warning')); ?>");
  <?php endif; ?>
</script>



<script type="text/javascript">
    // Place Order
    $("#checkOut").click(function (e) {
        e.preventDefault();
        var name = $("#uName").val();
        var email = $("#uEmail").val();
        var phone = $("#uPhone").val();
        var address = $("#uAddress").val();
        
        $.ajax({
            url: '<?php echo e(route('place.order')); ?>',
            method: "POST",
            data: {
                _token: '<?php echo e(csrf_token()); ?>',
                user_name: name,
                user_email: email,
                user_phone: phone,
                user_address: address,
            },
            success: function (response) {
                window.location.reload();
            }
        });
    });
    // var sprice = document.getElementById('singleProductPrice').innerText;
    // var sval = document.getElementById('singleProductVal').value;
    // document.getElementById("showProductPrice").innerHTML = sprice + sval;
        
    $('.quentity').change(function (e){
        var id = $(this).data('product_id');
        var qty = $(this).val();
        if(qty >= 1){
            
        var price = $('.price_' + id).val();
        console.log(id, qty, price);
        var cal = qty * price;
        $('.quentity_into_price_' + id).html(cal);
        
        
        e.preventDefault();
        var ele = $(this);
        $.ajax({
            url: '<?php echo e(route('cart.update')); ?>',
            method: "POST",
            data: {
                _token: '<?php echo e(csrf_token()); ?>', 
                id: ele.parents("tr").attr("rowId"), 
                quantity: ele.val(), 
            },
            success: function (response) {
                $('#total_price').html(response.total_price);
            }
        });
        }
        
        
    });
  
    // $(".quentity").change(function (e) {
        
    // });
  
    $(".delete-product").click(function (e) {
        e.preventDefault();
  
        var ele = $(this);
  
        if(confirm("Do you really want to delete?")) {
            $.ajax({
                url: '<?php echo e(route('cart.delete')); ?>',
                method: "DELETE",
                data: {
                    _token: '<?php echo e(csrf_token()); ?>', 
                    id: ele.parents("tr").attr("rowId")
                },
                success: function (response) {
                    window.location.reload();
                }
            });
        }
    });
  
</script>
<?php echo $__env->yieldPushContent('scripts'); ?><?php /**PATH /home/ptl4606q9941/public_html/web.au/resources/views/web/inc/scripts.blade.php ENDPATH**/ ?>