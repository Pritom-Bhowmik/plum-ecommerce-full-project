


<?php $__env->startSection('content'); ?>

<section id="prodetails" class="section-p1">
    <div class="single-pro-image">
      <img src="<?php echo e(asset('frontend/img/product/'.$service->image)); ?>" width="100%" id="mainimg" alt="">
      <div class="small-image-group">
        <div class="small-image-col">
          <img src="<?php echo e(asset('frontend/img/product/'.$service->image)); ?>" width="100%" class="small img" alt="">
        </div>
      </div>
    </div>

    <div class="single-pro-details">
      <h6><?php echo e($service->category); ?></h6>
      <h4> <?php echo e($service->title); ?></h4>
      <h2> £<?php echo e($service->price); ?> </h2>
      <a href="<?php echo e(route('cart.add', $service->id)); ?>"><button class="normal">Add To Cart</button></a>
      <h4>Product Details</h4>
      <span><?php echo $service->description; ?></span>

    </div>
  </section>
  <section id="product1" class="section-p1">
    <h2> Featured Products</h2>
    <p>Summer collection</p>
    <div class="pro-container">
        <?php $__currentLoopData = \App\Models\Service::orderBy('id', 'asc')->get()->take(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="pro">
            <a href="<?php echo e(route('web.shop.details', ['id' => $row->id])); ?>">
                <img src="<?php echo e(asset('frontend/img/product/'.$row->image)); ?>" alt="">
                <div class="des">
                    <span> <?php echo e($row->category); ?> </span>
                    <h5><?php echo e($row->title); ?></h5>
                    <div class="star">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                    </div>
                    <h4> £<?php echo e($row->price); ?></h4>
                </div>
                <a href="<?php echo e(route('cart.add', $row->id)); ?>"><i class="fa fa-shopping-cart"></i></a>
            </a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

  </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ptl4606q9941/public_html/web.au/resources/views/web/sproduct.blade.php ENDPATH**/ ?>