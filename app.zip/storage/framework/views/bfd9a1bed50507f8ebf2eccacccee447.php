


<?php $__env->startSection('content'); ?>

<section id="page-header" class="about-header" style="background-image: url('<?php echo e(asset('frontend/img/backgrounds/'.$about_page->thumbnail)); ?>');">
      
    <h2><?php echo e($about_page->page_title); ?></h2>
    
    <p> <?php echo e($about_page->page_description); ?> </p>
    

  </section>
  
  <section id="about-head" class="section-p1">
    <img src="<?php echo e(asset('/frontend/img/about/'.$about->thumbnail)); ?>" alt="">
    <div>
      <h2><?php echo $about->title; ?></h2>
      <p><?php echo $about->content; ?></p>

          <abbr title="">Join us in creating a greener fashion future.</abbr>
          <br><br>

          <marquee bgcolor="#ccc" loop="1" scrollermount="5" width="100%"> Create your own look</marquee>
    </div>
</section>

  <section id="about-app" class="section-p1">
    <h1> Download Our <a href="#">App</a> </h1>
    <div class="video">
      <video autoplay muted loop src="<?php echo e(asset('/frontend/img/about/'.$about->video)); ?>"></video>
    </div>
  </section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ptl4606q9941/public_html/web.au/resources/views/web/about.blade.php ENDPATH**/ ?>