<link rel="stylesheet" href="<?php echo e(asset('frontend/style/style.css')); ?>">
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<script src="https://kit.fontawesome.com/fd479ff4ae.js" crossorigin="anonymous"></script>
<?php /**PATH /home/ptl4606q9941/public_html/web.au/resources/views/web/inc/styles.blade.php ENDPATH**/ ?>