

<?php $__env->startSection('content'); ?>

<div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="container">

            <!-- Page-Title -->
            <div class="row">
                <div class="col-sm-12">
                    <h4 class="pull-left page-title">All Pages</h4>
                    <ol class="breadcrumb pull-right">
                        <li><a href="<?php echo e(route('backend.dashboard')); ?>">Dashboard</a></li>
                        <li class="active">All Pages</li>
                    </ol>
                </div>
            </div>

            <div class="row">
                <!-- Basic example -->
                <div class="col-md-12">
                    <div class="panel panel-default">
                        <div class="panel-heading content-between">
                            <h3 class="panel-title">View Table</h3>
                            <!--<a class="btn btn-primary" href="<?php echo e(route('backend.users.create')); ?>">Add New</a>-->
                        </div>
                        <div class="panel-body">
                            <div class="row">
                            <table id="datatable" class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th width="5%">#</th>
                                        <th width="35%">Page Name</th>
                                        <th width="35%">Page Title</th>
                                        <th width="10%">Thumbnail</th>
                                        <th width="10%">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = \App\Models\Page::orderBy('page_name', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->index+1); ?></td>
                                        <td><?php echo e($row->page_name); ?></td>
                                        <td><?php echo e($row->page_title); ?></td>
                                        <td>
                                            <img class="img-thumbnail" src="<?php echo e(asset('frontend/img/backgrounds/'.$row->thumbnail)); ?>" />
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('backend.content.pages.edit', $row->slug)); ?>" class="btn btn-warning btn-sm">Edit</a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div><!-- panel-body -->
                    </div> <!-- panel -->
                </div> <!-- col-->
            </div>

        </div> <!-- container -->
    </div> <!-- content -->
</div> <!-- content-page -->


<?php $__env->stopSection(); ?>





<?php $__env->startPush('meta'); ?>

<?php $__env->stopPush(); ?>




<?php $__env->startPush('styles_top'); ?>

<?php $__env->stopPush(); ?>




<?php $__env->startPush('styles'); ?>
<link href="<?php echo e(asset('/backend/assets/datatables/jquery.dataTables.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopPush(); ?>




<?php $__env->startPush('scripts_head'); ?>

<?php $__env->stopPush(); ?>




<?php $__env->startPush('scripts_top'); ?>

<?php $__env->stopPush(); ?>




<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('/backend/assets/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('/backend/assets/datatables/dataTables.bootstrap.js')); ?>"></script>
<script type="text/javascript">
    $(document).ready(function() {
        var datatable = $('#datatable').dataTable();
        
        
        
    });
</script>
<?php $__env->stopPush(); ?>



<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ptl4606q9941/public_html/web.au/resources/views/backend/pages/index.blade.php ENDPATH**/ ?>