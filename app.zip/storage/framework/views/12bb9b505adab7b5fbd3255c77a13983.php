

    <?php echo $__env->make('backend.layouts.inc.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH /home/ptl4606q9941/public_html/web.au/resources/views/backend/layouts/inc/footer.blade.php ENDPATH**/ ?>