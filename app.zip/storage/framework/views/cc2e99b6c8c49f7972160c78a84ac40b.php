<?php if(session()->has('success')): ?>
    <div class="alert alert-success alert-dismissible show" role="alert">
        <?php echo e(session()->get('success')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php endif; ?>

<?php if(session()->has('error')): ?>
    <div class="alert alert-danger alert-dismissible show" role="alert">
        <?php echo e(session()->get('error')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php endif; ?><?php /**PATH /home/ptl4606q9941/public_html/web.au/resources/views/backend/layouts/message.blade.php ENDPATH**/ ?>