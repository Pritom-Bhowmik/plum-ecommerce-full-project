


<?php $__env->startSection('content'); ?>

<section id="page-header" style="background-image: url('<?php echo e(asset('frontend/img/backgrounds/'.$shop_page->thumbnail)); ?>');">
      
    <h2><?php echo e($shop_page->page_title); ?></h2>
    
    <p> <?php echo e($shop_page->page_description); ?> </p>
    

  </section>

  <section id="product1" class="section-p1">
    
    <div class="pro-container">
        <?php $__currentLoopData = \App\Models\Service::orderBy('id', 'asc')->get()->take(12); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="pro">
            <a href="<?php echo e(route('web.shop.details', ['id' => $row->id])); ?>">
                <img src="<?php echo e(asset('frontend/img/product/'.$row->image)); ?>" alt="">
                <div class="des">
                    <span> <?php echo e($row->category); ?> </span>
                    <h5><?php echo e($row->title); ?></h5>
                    <div class="star">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                    </div>
                    <h4> £<?php echo e($row->price); ?></h4>
                </div>
                <a href="<?php echo e(route('cart.add', $row->id)); ?>"><i class="fa fa-shopping-cart"></i></a>
            </a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

  </section>

  <!--<section id="pagination" class="section-p1">-->
  <!--  <a href="#">1</a>-->
  <!--  <a href="#">2</a>-->
  <!--  <a href="#"><i class="fas fa-long-arrow-alt-right"></i></a>-->
  <!--</section>-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ptl4606q9941/public_html/web.au/resources/views/web/shop.blade.php ENDPATH**/ ?>