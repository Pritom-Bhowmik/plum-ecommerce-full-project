


<?php $__env->startSection('content'); ?>

<section id="page-header">
      
    <h2 style="color:black;"> Cart</h2>
    
    <p style="color:black;">Thank you for sopping with us </p>
    

    </section>
    <section id="cart" class="section-p1">
      <table width="100%">
        <thead>
          <tr>
            <td> Remove</td>
            <td> Images</td>
            <td> Product</td>
            <td> Price</td>
            <td> Quantity</td>
            <td> Subtotal</td>
          </tr>
        </thead>
        <tbody>
            <?php
                $total_price = 0;
            ?>
            <?php if(session('cart')): ?>
                <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr rowId="<?php echo e($id); ?>">
                        <td><a href="#" class="delete-product"><i class="far fa-times-circle"></i></a></td>
                        <td> <img src="<?php echo e(asset('frontend/img/product/'.$details['image'])); ?>" alt=""></td>
                        <td> <?php echo e($details['title']); ?></td>
                        <td id="singleProductPrice"> £<?php echo e($details['price']); ?> 
                            <input type="hidden" value="<?php echo e($details['price']); ?>" class="price_<?php echo e($id); ?>">
                        </td>
                        
                        <td> <input type="number" class="quentity" id="edit-cart-info" data-product_id="<?php echo e($id); ?>" value="<?php echo e($details['quantity']); ?>"></td>
                        <td> £ <span class="quentity_into_price quentity_into_price_<?php echo e($id); ?>"><?php echo e($details['price'] * $details['quantity']); ?></span></td>
                    </tr>
                    <?php
                    $total_price = ($total_price+($details['price'] * $details['quantity']));
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <tr>
                    <td colspan="6">
                         <p>No product available here</p>
                    </td>
                </tr>
            <?php endif; ?>
            
        </tbody>
      </table>
    </section>
    <section id="cart-add" class="section-p1">
      <div id="coupon">
        <h3> Give Your Details</h3>
        <div>
          <input type="text" id="uName" required placeholder="Enter Name">
        </div>
        <div>
          <input type="email" id="uEmail" required placeholder="Enter Email">
        </div>
        <div>
          <input type="number" id="uPhone" required placeholder="Enter Phone">
        </div>
        <div>
          <input type="text" id="uAddress" required placeholder="Enter Address">
        </div>
      </div>
      <div id="subtotal">
        <h3>Cart Total</h3>
        <table>
          <tr>
                <td>Subtotal</td>
                <td>£
                    <?php if(session('cart')): ?>
                        <?php echo e($total_price); ?>

                    <?php else: ?>
                        NAN
                    <?php endif; ?>
                </td>
          </tr>
          <tr>
            <td>Shipping</td>
            <td> Free</td>
          </tr>
          <tr>
            <td><strong>Total</strong></td>
            <td>
                <strong id="total_price"> £
                    <?php if(session('cart')): ?>
                        <?php echo e($total_price); ?>

                    <?php else: ?>
                        NAN
                    <?php endif; ?>
                </strong>
            </td>
        </table>
        <button class="normal" id="checkOut">Proceed to checkout </button>
      </div>
    </section>
  </section>

<?php $__env->stopSection(); ?>
  

<?php echo $__env->make('web.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ptl4606q9941/public_html/web.au/resources/views/web/cart.blade.php ENDPATH**/ ?>