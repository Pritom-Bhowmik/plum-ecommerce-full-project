

<?php $__env->startSection('content'); ?>

<div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="container">

            <!-- Page-Title -->
            <div class="row">
                <div class="col-sm-12">
                    <h4 class="pull-left page-title">Add New</h4>
                    <ol class="breadcrumb pull-right">
                        <li><a href="<?php echo e(route('backend.dashboard')); ?>">Dashboard</a></li>
                        <li><a href="<?php echo e(route('backend.users.index')); ?>">All Admins</a></li>
                        <li class="active">Add New</li>
                    </ol>
                </div>
            </div>

            <div class="row">
                <!-- Basic example -->
                <div class="col-md-8">
                    <div class="panel panel-default">
                        <div class="panel-heading"><h3 class="panel-title">Create a new admin</h3></div>
                        <div class="panel-body">
                            <form id="form" role="form" action="<?php echo e(route('backend.users.create')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label>Name:</label>
                                    <input type="text" class="form-control" name="name"  placeholder="Enter name">
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="error-message"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <label for="">Email address:</label>
                                    <input type="email" class="form-control"  name="email" placeholder="Enter email">
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="error-message"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <label>Password:</label>
                                    <input type="password" class="form-control" name="password" placeholder="Password">
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="error-message"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <label for="">Avatar:</label>
                                    <input type="file" class="form-control" accept=".jpeg, .png, .gif, .svg, .webp" id="avatar" name="avatar" placeholder="Enter email">
                                    <span class="note"><strong>Accepted Image Type:</strong> .jpeg, .jpg, .png, .gif, .svg, .webp</span>
                                    <?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="error-message"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <button type="submit" class="spin btn btn-purple waves-effect waves-light">
                                    <svg class="spinner" viewBox="0 0 50 50">
                                        <circle class="path" cx="25" cy="25" r="20" fill="none" stroke-width="5"></circle>
                                    </svg>
                                    Submit
                                </button>
                            </form>
                        </div><!-- panel-body -->
                    </div> <!-- panel -->
                </div> <!-- col-->
                <div class="col-md-4">
                    <div class="panel panel-default">
                        <div class="panel-heading"><h3 class="panel-title">Preview Avatar</h3></div>
                        <div class="panel-body">
                            <div class="">
                                <div class="">
                                    <img id="preview_avatar" class="img-thumbnail" src="https://via.placeholder.com/200x200" data-src="https://via.placeholder.com/200x200" alt="" style="max-width:250px;">
                                    <br>
                                    <label id="avatar_name"></label>
                                </div>
                            </div>
                        </div><!-- panel-body -->
                    </div> <!-- panel -->
                </div> <!-- col-->
            </div>

        </div> <!-- container -->
    </div> <!-- content -->
</div> <!-- content-page -->


<?php $__env->stopSection(); ?>





<?php $__env->startPush('meta'); ?>

<?php $__env->stopPush(); ?>




<?php $__env->startPush('styles_top'); ?>

<?php $__env->stopPush(); ?>




<?php $__env->startPush('styles'); ?>
<style>

</style>
<?php $__env->stopPush(); ?>




<?php $__env->startPush('scripts_head'); ?>

<?php $__env->stopPush(); ?>




<?php $__env->startPush('scripts_top'); ?>

<?php $__env->stopPush(); ?>




<?php $__env->startPush('scripts'); ?>
<script>
$('#form').submit(function(e){
    e.preventDefault();
    $.ajax({
        url:"<?php echo e(route('backend.users.store')); ?>",
        type: "POST",
        data:new FormData(this),
        cache: false,
        contentType: false,
        processData: false,                        
        beforeSend:function(res){
            $('#form').find('button').attr('disabled', true);
        },
        success:function(res){
            ToastMessage(res.status?"Success":"Error", res.message, res.status?'success':"error");
            $('button[type="submit"]').removeAttr('disabled');
            $('.error-message').remove();
            if(!res.status && Object.keys(res.errors).length > 0){
                Object.keys(res.errors).forEach(function(key, index){
                    var targetEl = $('#form').find('input[name="'+key+'"]')[0];
                    $(targetEl).after(`<span class="error-message">${res.errors[key][0]}</span>`);
                });
            }else{
                $('#form')[0].reset();
                $('#preview_avatar').attr('src', $('#preview_avatar').data('src'));
                $('#avatar_name').text('');
            }
        },
        error:function(res){
            ToastMessage("Error", 'Something went wrong please try again.', 'error');
        },
        complete:function(res){
            console.log('complete', res);
        }
    });
    
});

$('#avatar').change(function(){
    if(this.files.length > 0){
        var file = this.files[0];
        $('#preview_avatar').attr('src', URL.createObjectURL(file));
        $('#avatar_name').text(file.name);
    }
});



</script>
<?php $__env->stopPush(); ?>



<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ptl4606q9941/public_html/web.au/resources/views/backend/admin/create.blade.php ENDPATH**/ ?>