

<?php $__env->startSection('content'); ?>

<div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="container">

            <!-- Page-Title -->
            <div class="row">
                <div class="col-sm-12">
                    <h4 class="pull-left page-title">Edit Page</h4>
                    <ol class="breadcrumb pull-right">
                        <li><a href="<?php echo e(route('backend.dashboard')); ?>">Dashboard</a></li>
                        <li class="active">Edit Page</li>
                    </ol>
                </div>
            </div>

            <div class="row">
                <!-- Basic example -->
                <div class="col-md-12">
                    <div class="panel panel-default">
                        <div class="panel-heading"><h3 class="panel-title">Edit <?php echo e(ucfirst($edit->page_name)); ?> Page</h3></div>
                        <div class="panel-body">
                            <form id="form" role="form" action="<?php echo e(route('backend.content.pages.update', $edit->slug)); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label>Page Name:</label>
                                    <input type="text" class="form-control" name="page_name" value="<?php echo e(old('page_name', $edit->page_name)); ?>">
                                    <?php $__errorArgs = ['page_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="error-message"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <label>Page Title:</label>
                                    <input type="text" class="form-control" name="page_title" value="<?php echo e(old('page_title', $edit->page_title)); ?>">
                                    <?php $__errorArgs = ['page_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="error-message"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <div class="form-group">
                                    <label>Page Description:</label>
                                    <textarea type="text" class="form-control" name="page_description" rows="3"><?php echo e(old('page_description', $edit->page_description)); ?></textarea>
                                    <?php $__errorArgs = ['page_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="error-message"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <div class="form-group">
                                    <label>Page Content:</label>
                                    <textarea type="text" class="form-control" name="page_content" rows="10"><?php echo e(old('page_content', $edit->page_content)); ?></textarea>
                                    <?php $__errorArgs = ['page_content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="error-message"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <div class="form-group">
                                    <label>Meta Title:</label>
                                    <textarea type="text" class="form-control" name="meta_title" rows="3"><?php echo e(old('meta_title', $edit->meta_title)); ?></textarea>
                                    <?php $__errorArgs = ['meta_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="error-message"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <div class="form-group">
                                    <label>Meta Description:</label>
                                    <textarea type="text" class="form-control" name="meta_description" rows="3"><?php echo e(old('meta_description', $edit->meta_description)); ?></textarea>
                                    <?php $__errorArgs = ['meta_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="error-message"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <div class="form-group">
                                    <label>Meta Keyword:</label>
                                    <textarea type="text" class="form-control" name="meta_keyword" rows="3"><?php echo e(old('meta_keyword', $edit->meta_keyword)); ?></textarea>
                                    <?php $__errorArgs = ['meta_keyword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="error-message"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                               
                               
                               
                                <div class="form-group">
                                    <label for="">Thumbnail: (2048 x 1536)</label>
                                    <input type="file" class="form-control" accept=".jpeg, .png, .gif, .svg, .webp" id="avatar" name="thumbnail">
                                    <span class="note"><strong>Accepted Image Type:</strong> .jpeg, .jpg, .png, .gif, .svg, .webp</span>
                                    <?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="error-message"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group d-block">
                                    <label class="d-block">Thumbnail Preview:</label>
                                    <div class="row">
                                        <div class="col-lg-3 col-md-6">
                                            <br>
                                            <?php if($edit->thumbnail): ?>
                                            <img class="img-thumbnail" src="<?php echo e(asset('frontend/img/backgrounds/'.$edit->thumbnail)); ?>">
                                            <?php else: ?>
                                            <img class="img-thumbnail" src="https://via.placeholder.com/300x120">
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <br>
                                <div class="d-block">
                                    <button type="submit" class="spin btn btn-purple waves-effect waves-light">
                                        Submit
                                    </button>
                                </div>
                            </form>
                        </div><!-- panel-body -->
                    </div> <!-- panel -->
                </div> <!-- col-->
            </div>

        </div> <!-- container -->
    </div> <!-- content -->
</div> <!-- content-page -->


<?php $__env->stopSection(); ?>





<?php $__env->startPush('meta'); ?>

<?php $__env->stopPush(); ?>




<?php $__env->startPush('styles_top'); ?>

<?php $__env->stopPush(); ?>




<?php $__env->startPush('styles'); ?>
<style>

</style>
<?php $__env->stopPush(); ?>




<?php $__env->startPush('scripts_head'); ?>
<script src="https://cdn.ckeditor.com/4.16.0/full-all/ckeditor.js"></script>

<?php $__env->stopPush(); ?>




<?php $__env->startPush('scripts_top'); ?>
<script>
    CKEDITOR.replace('page_content');
</script>

<?php $__env->stopPush(); ?>




<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>



<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ptl4606q9941/public_html/web.au/resources/views/backend/pages/edit.blade.php ENDPATH**/ ?>