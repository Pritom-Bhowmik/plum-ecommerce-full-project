

<?php $__env->startSection('content'); ?>

<div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="container">
            <form id="form" role="form" action="" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <!-- Page-Title -->
                <div class="row">
                    <div class="col-sm-12">
                        <h4 class="pull-left page-title">General Settings</h4>
                        <ol class="breadcrumb pull-right">
                            <li><a href="<?php echo e(route('backend.dashboard')); ?>">Dashboard</a></li>
                            <li><a href="">All Logos</a></li>
                            <li class="active">General Settings</li>
                        </ol>
                    </div>
                </div>

                <div class="row">
                    <!-- Basic example -->
                    <div class="col-md-6">
                        <div class="panel panel-default">
                            <div class="panel-heading"><h3 class="panel-title">General Settings</h3></div>
                            <div class="panel-body">
                                <div class="form-group">
                                    <label>Site Name:</label>
                                    <input type="text" class="form-control" name="site_name"  value="<?php echo e($setting->site_name); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="">Site Type:</label>
                                    <input type="text" class="form-control" name="site_type"  value="<?php echo e($setting->site_type); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="">Address:</label>
                                    <textarea type="text" class="form-control" name="address"><?php echo e($setting->address); ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="">Copy Right:</label>
                                    <input type="text" class="form-control" name="copy_right" value="<?php echo e($setting->copy_right); ?>">
                                </div>                           
                                <div class="form-group">
                                    <label for="">Logo (78x79):</label>
                                    <input type="file" class="form-control" name="logo">
                                </div>                                    
                                <div class="form-group">
                                    <img id="logo" style="width:100px;" class="img-thumbnail" src="<?php echo e($setting->logo?asset('/storage/logo/'.$setting->logo):'https://via.placeholder.com/80x80'); ?>" alt="">
                                </div>                                    
                                <div class="form-group">
                                    <label for="">Favicon: (32x32)</label>
                                    <input type="file" class="form-control" name="favicon">
                                </div>                                    
                                <div class="form-group">
                                    <img id="favicon"  style="width:60px;" class="img-thumbnail" src="<?php echo e($setting->favicon?asset('/storage/logo/'.$setting->favicon):'https://via.placeholder.com/60x60'); ?>" alt="">
                                </div> 
                                <div>
                                    <button type="submit" class="spin btn btn-primary waves-effect waves-light">
                                        <svg class="spinner" viewBox="0 0 50 50">
                                            <circle class="path" cx="25" cy="25" r="20" fill="none" stroke-width="5"></circle>
                                        </svg>
                                        Update
                                    </button>
                                </div>
                            </div><!-- panel-body -->
                        </div> <!-- panel -->
                    </div>
                    <div class="col-md-6">
                        <div class="panel panel-default">
                            <div class="panel-heading"><h3 class="panel-title">Social Link</h3></div>
                            <div class="panel-body">
                                <div class="form-group">
                                    <label for="">Google Map Lat,Long:</label>
                                    <input type="text" class="form-control" name="map_latlong" value="<?php echo e($setting->map_latlong); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="">Email:</label>
                                    <input type="text" class="form-control" name="email" value="<?php echo e($setting->email); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="">Phone:</label>
                                    <input type="text" class="form-control" name="phone"  value="<?php echo e($setting->phone); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="">Facebook:</label>
                                    <input type="text" class="form-control" name="facebook" value="<?php echo e($setting->facebook); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="">Twitter:</label>
                                    <input type="text" class="form-control" name="twitter"  value="<?php echo e($setting->twitter); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="">Instagram:</label>
                                    <input id="tags" type="text" class="form-control" name="instagram"  value="<?php echo e($setting->instagram); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="">Linkedin:</label>
                                    <input type="text" class="form-control" name="linkedin" value="<?php echo e($setting->instagram); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="">Google Script:</label>
                                    <textarea type="text" class="form-control" name="google_script" rows="6"><?php echo e($setting->google_script); ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="">Background Color: ( #18130C )</label>
                                    <input type="color" class="form-control" name="background_color" value="<?php echo e($setting->background_color); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="">Text Color: ( #A8A7A5 )</label>
                                    <input type="color" class="form-control" name="text_color" value="<?php echo e($setting->text_color); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="">Icon Color: ( #B88768 )</label>
                                    <input type="color" class="form-control" name="icon_color" value="<?php echo e($setting->icon_color); ?>">
                                </div>
                                <div class="form-group">
                                    <label>
                                        <input type="checkbox" name="default_color">
                                        Default Color
                                    </label>
                                </div>
                            </div><!-- panel-body -->
                        </div> <!-- panel -->
                    </div>
                </div>
            </form>
        </div> <!-- container -->
    </div> <!-- content -->
</div> <!-- content-page -->

<?php $__env->stopSection(); ?>





<?php $__env->startPush('meta'); ?>

<?php $__env->stopPush(); ?>




<?php $__env->startPush('styles_top'); ?>

<?php $__env->stopPush(); ?>




<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('backend/assets/tags/style.css')); ?>">
<style>
.acc{
    margin-bottom:12px;
}
.acc .panel-heading{
    cursor:pointer;
    border-top-left-radius:5px;
    border-top-right-radius:5px;
}
.acc .acc-toggler.active{
    background:#317eeb;
    color:#ffffff;
}
.acc-body{
    display:none;
}
</style>
<?php $__env->stopPush(); ?>




<?php $__env->startPush('scripts_head'); ?>
<script src="https://cdn.ckeditor.com/4.16.0/full-all/ckeditor.js"></script>
<?php $__env->stopPush(); ?>




<?php $__env->startPush('scripts_top'); ?>

<?php $__env->stopPush(); ?>




<?php $__env->startPush('scripts'); ?>

<script>

CKEDITOR.replace('address');

$('#form').submit(function(e){
    e.preventDefault();
    $.ajax({
        url:"<?php echo e(route('backend.settings.update')); ?>",
        type: "POST",
        data:new FormData(this),
        cache: false,
        contentType: false,
        processData: false,                        
        beforeSend:function(res){
            $('#form').find('button').attr('disabled', true);
        },
        success:function(res){
            console.log(res);
            ToastMessage(res.status?"Success":"Error", res.message, res.status?'success':"error");
            $('.error-message').remove();
            if(!res.status && Object.keys(res.errors).length > 0){
                Object.keys(res.errors).forEach(function(key, index){
                    var targetEl = $('#form').find('input[name="'+key+'"]')[0] || $('#form').find('select[name="'+key+'"]')[0] || $('#form').find('textarea[name="'+key+'"]')[0];
                    $(targetEl).after(`<span class="error-message">${res.errors[key][0]}</span>`);
                });
            }else{
            }
        },
        error:function(res){
            ToastMessage("Error", 'Something went wrong please try again.', 'error');
        },
        complete:function(res){
            $('#form').find('button').removeAttr('disabled', true);
        }
    });
    
});

$('input[type="file"]').change(function(){
    if(this.files.length > 0){
        var file = this.files[0];
        $("#"+this.name).attr('src', URL.createObjectURL(file));
    }
});



</script>
<?php $__env->stopPush(); ?>



<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ptl4606q9941/public_html/web.au/resources/views/backend/settings/edit.blade.php ENDPATH**/ ?>