<?php echo csrf_field(); ?>
                                
<div class="form-group">
    <label>Title:</label>
    <input type="text" class="form-control" name="title" value="<?php echo e(old('title', optional($edit)->title)); ?>" required>
    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="error-message"><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="form-group">
    <label>Description:</label>
    <input type="text" class="form-control" name="description" value="<?php echo e(old('description', optional($edit)->description)); ?>" required>
    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="error-message"><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group">
    <label for="">Thumbnail: (1800 x 1801)</label>
    <input type="file" class="form-control" accept=".jpeg, .png, .gif, .svg, .webp" id="avatar" name="thumbnail" required>
    <span class="note"><strong>Accepted Image Type:</strong> .jpeg, .jpg, .png, .gif, .svg, .webp</span>
    <?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="error-message"><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="form-group d-block">
    <label class="d-block">Thumbnail Preview:</label>
    <div class="row">
        <div class="col-lg-2 col-md-4">
            <br>
            <?php if(optional($edit)->thumbnail): ?>
            <img id="avatar_preview" class="img-thumbnail" src="<?php echo e(asset('/frontend/img/blog/'.optional($edit)->thumbnail)); ?>">
            <?php else: ?>
            <img id="avatar_preview" class="img-thumbnail" src="https://via.placeholder.com/300x400">
            <?php endif; ?>
        </div>
    </div>
</div>
<br>
<br>

<div class="d-block">
    <button type="submit" class="spin btn btn-purple waves-effect waves-light">
        Submit
    </button>
</div><?php /**PATH /home/ptl4606q9941/public_html/web.au/resources/views/backend/blog/form.blade.php ENDPATH**/ ?>