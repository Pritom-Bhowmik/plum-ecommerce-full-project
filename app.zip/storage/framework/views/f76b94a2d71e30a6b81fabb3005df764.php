

<?php $__env->startSection('content'); ?>

<div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="container">

            <!-- Page-Title -->
            <div class="row">
                <div class="col-sm-12">
                    <h4 class="pull-left page-title">All Categories</h4>
                    <ol class="breadcrumb pull-right">
                        <li><a href="<?php echo e(route('backend.dashboard')); ?>">Dashboard</a></li>
                        <li class="active">All Categories</li>
                    </ol>
                </div>
            </div>

            <div class="row">
                <!-- Basic example -->
                <div class="col-md-12">
                    <div class="panel panel-default">
                        <div class="panel-heading content-between">
                            <h3 class="panel-title">View Table</h3>
                            <a class="btn btn-primary" href="<?php echo e(route('backend.categories.create')); ?>">Add New</a>
                        </div>
                        <div class="panel-body">
                            <div class="row">
                            <table class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th width="5%">#</th>
                                        <th>Categorie Name</th>
                                        <th>Categorie Image</th>
                                        <th width="10%">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $key = 0;
                                    ?>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key++); ?></td>
                                        <td><?php echo e($data->name); ?></td>
                                        <td>
                                            <img height="80" src="<?php echo e(asset('frontend/img/category/'.$data->image)); ?>" />
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('backend.categories.edit', $data->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                                            <a href="<?php echo e(route('backend.categories.delete', $data->id)); ?>" class="btn btn-danger btn-sm">Delete</a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div><!-- panel-body -->
                    </div> <!-- panel -->
                </div> <!-- col-->
            </div>

        </div> <!-- container -->
    </div> <!-- content -->
</div> <!-- content-page -->


<?php $__env->stopSection(); ?>





<?php $__env->startPush('meta'); ?>

<?php $__env->stopPush(); ?>




<?php $__env->startPush('styles_top'); ?>

<?php $__env->stopPush(); ?>




<?php $__env->startPush('styles'); ?>
<link href="<?php echo e(asset('/backend/assets/datatables/jquery.dataTables.min.css')); ?>" rel="stylesheet" type="text/css" />
<style>
ul{
    margin:0px;
    padding:0px;
}
.sub-cat{
    border-radius:5px;
    padding:3px 0px; 
}
.sub-cat:hover{
    background: linear-gradient(45deg, #e3ecf7, #f2f2f2);
}
</style>
<?php $__env->stopPush(); ?>




<?php $__env->startPush('scripts_head'); ?>

<?php $__env->stopPush(); ?>




<?php $__env->startPush('scripts_top'); ?>

<?php $__env->stopPush(); ?>




<?php $__env->startPush('scripts'); ?>

<?php $__env->stopPush(); ?>



<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ptl4606q9941/public_html/web.au/resources/views/backend/categorie/index.blade.php ENDPATH**/ ?>