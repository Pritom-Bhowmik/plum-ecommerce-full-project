

<?php $__env->startSection('content'); ?>

<div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="container">

            <!-- Page-Title -->
            <div class="row">
                <div class="col-sm-12">
                    <h4 class="pull-left page-title">Edit Product</h4>
                    <ol class="breadcrumb pull-right">
                        <li><a href="<?php echo e(route('backend.dashboard')); ?>">Dashboard</a></li>
                        <li class="active">Edit Product</li>
                    </ol>
                </div>
            </div>

            <div class="row">
                <!-- Basic example -->
                <div class="col-md-12">
                    <div class="panel panel-default">
                        <div class="panel-heading"><h3 class="panel-title">Edit Product</h3></div>
                        <div class="panel-body">
                            <form id="form" role="form" action="<?php echo e(route('backend.content.services.update', $edit->id)); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                
                                <div class="form-group">
                                    <label>Product Title:</label>
                                    <input type="text" class="form-control" value="<?php echo e($edit->title); ?>" name="product_title"  placeholder="Enter Title">
                                    <?php $__errorArgs = ['product_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="error-message"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <div class="form-group">
                                    <label for="">Product Image</label>
                                    <input type="file" class="form-control" accept=".jpeg, .png, .gif, .svg, .webp" name="product_image">
                                    <span class="note"><strong>Accepted Image Type:</strong> .jpeg, .jpg, .png, .gif, .svg, .webp</span>
                                    <?php $__errorArgs = ['product_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="error-message"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group d-block">
                                    <label class="d-block">Avatar Preview:</label>
                                    <div class="row">
                                        <div class="col-lg-2 col-md-4">
                                            <br>
                                            <?php if(optional($edit)->image): ?>
                                            <img id="avatar_preview" class="img-thumbnail" src="<?php echo e(asset('/frontend/img/product/'.optional($edit)->image)); ?>">
                                            <?php else: ?>
                                            <img id="avatar_preview" class="img-thumbnail" src="https://via.placeholder.com/170x280">
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <label>Product Category:</label>
                                    <select class="form-control" name="product_category">
                                        <option>Choose Category</option>
                                        <?php $__currentLoopData = \App\Models\Categorie::orderBy('id', 'asc')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($row->name); ?>" <?php if($row->name == $edit->category){echo "selected";} ?> ><?php echo e($row->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['product_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="error-message"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <div class="form-group">
                                    <label>Product Price:</label>
                                    <input type="text" class="form-control" value="<?php echo e($edit->price); ?>" name="product_price"  placeholder="Enter Price">
                                    <?php $__errorArgs = ['product_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="error-message"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <div class="form-group">
                                    <label>Product Description:</label>
                                    <textarea type="text" class="form-control" name="product_description" rows="3" placeholder="Enter Description"><?php echo $edit->description; ?></textarea>
                                    <?php $__errorArgs = ['product_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="error-message"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <br>
                                <div class="d-block">
                                    <button type="submit" class="spin btn btn-purple waves-effect waves-light">
                                        Submit
                                    </button>
                                </div>
                            </form>
                        </div><!-- panel-body -->
                    </div> <!-- panel -->
                </div> <!-- col-->
            </div>

        </div> <!-- container -->
    </div> <!-- content -->
</div> <!-- content-page -->


<?php $__env->stopSection(); ?>





<?php $__env->startPush('meta'); ?>

<?php $__env->stopPush(); ?>




<?php $__env->startPush('styles_top'); ?>

<?php $__env->stopPush(); ?>




<?php $__env->startPush('styles'); ?>
<style>

</style>
<?php $__env->stopPush(); ?>




<?php $__env->startPush('scripts_head'); ?>
<script src="https://cdn.ckeditor.com/4.16.0/full-all/ckeditor.js"></script>

<?php $__env->stopPush(); ?>




<?php $__env->startPush('scripts_top'); ?>
<script>
    CKEDITOR.replace('product_description');
</script>

<?php $__env->stopPush(); ?>




<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>



<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ptl4606q9941/public_html/web.au/resources/views/backend/service/edit.blade.php ENDPATH**/ ?>