<section id="header">
    <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('/storage/logo/'.$setting->logo)); ?>" class="logo"alt=""></a>
    <div>
      <ul id="navbar">
        <li> <a class="active" href="<?php echo e(url('/')); ?>">Home</a></li>
        <li> <a href="<?php echo e(route('web.shop')); ?>">Shop</a></li>
        <li> <a href="<?php echo e(route('web.blog')); ?>">Blog</a></li>
        <li> <a href="<?php echo e(route('web.about')); ?>">About</a></li>
        <li> <a href="<?php echo e(route('web.contact')); ?>">Contact</a></li>
        <li id="lg-bag"><a href="<?php echo e(route('web.cart')); ?>"><i class="fa fa-bag-shopping"></i><span style="color:#088178; font-size: 22px;">
            <?php if(session('cart')): ?>
                <?php $count = 0; ?>
                <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $count++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo $count; ?>
            <?php else: ?>
                0
            <?php endif; ?>
        </span></a></li>
        <a href="#" id="close"><i class="fa fa-times"></i></a>
      </ul>
    </div>
    <div id="mobile">
      <a href="<?php echo e(route('web.cart')); ?>"><i class="fa-regular fa-bag-shopping"></i></a>
      <i id="bar" class="fa fa-outdent"></i>
    </div>
</section><?php /**PATH /home/ptl4606q9941/public_html/web.au/resources/views/web/layouts/navbar.blade.php ENDPATH**/ ?>