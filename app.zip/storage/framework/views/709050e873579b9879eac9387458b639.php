

<?php $__env->startSection('content'); ?>

<div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="container">

            <!-- Page-Title -->
            <div class="row">
                <div class="col-sm-12">
                    <h4 class="pull-left page-title">Edit Blog</h4>
                    <ol class="breadcrumb pull-right">
                        <li><a href="<?php echo e(route('backend.dashboard')); ?>">Dashboard</a></li>
                        <li class="active">Edit Blog</li>
                    </ol>
                </div>
            </div>

            <div class="row">
                <!-- Basic example -->
                <div class="col-md-12">
                    <div class="panel panel-default">
                        <div class="panel-heading"><h3 class="panel-title">Edit</h3></div>
                        <div class="panel-body">
                            <form id="form" role="form" action="<?php echo e(route('backend.blog.update', $edit->id)); ?>" method="post" enctype="multipart/form-data">
                                <?php echo $__env->make('backend.blog.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </form>
                        </div><!-- panel-body -->
                    </div> <!-- panel -->
                </div> <!-- col-->
            </div>

        </div> <!-- container -->
    </div> <!-- content -->
</div> <!-- content-page -->


<?php $__env->stopSection(); ?>





<?php $__env->startPush('meta'); ?>

<?php $__env->stopPush(); ?>




<?php $__env->startPush('styles_top'); ?>

<?php $__env->stopPush(); ?>




<?php $__env->startPush('styles'); ?>
<style>

</style>
<?php $__env->stopPush(); ?>




<?php $__env->startPush('scripts_head'); ?>

<?php $__env->stopPush(); ?>




<?php $__env->startPush('scripts_top'); ?>
<script>
    
    
    $('#avatar').change(function(){
    if(this.files.length > 0){
        var file = this.files[0];
        $('#avatar_preview').attr('src', URL.createObjectURL(file));
        }
    });
    
    
</script>

<?php $__env->stopPush(); ?>




<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>



<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ptl4606q9941/public_html/web.au/resources/views/backend/blog/edit.blade.php ENDPATH**/ ?>