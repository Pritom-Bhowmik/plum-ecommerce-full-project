

<?php $__env->startSection('content'); ?>

<div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="container">

            <!-- Page-Title -->
            <div class="row">
                <div class="col-sm-12">
                    <h4 class="pull-left page-title">Contacts</h4>
                    <ol class="breadcrumb pull-right">
                        <li><a href="<?php echo e(route('backend.dashboard')); ?>">Dashboard</a></li>
                        <li class="active">Contacts</li>
                    </ol>
                </div>
            </div>

            <div class="row">
                <!-- Basic example -->
                <div class="col-md-12">
                    <div class="panel panel-default">
                        <div class="panel-heading content-between">
                            <h3 class="panel-title">View Table</h3>
                        </div>
                        <div class="panel-body">
                            <div class="row">
                            <table id="datatable" class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th width="5%">#</th>
                                        <th width="10%">Name</th>
                                        <th width="10%">Email</th>
                                        <th width="25%">Subject</th>
                                        <th width="40%">Message</th>
                                        <th width="20%">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = \App\Models\Contact::orderBy('id', 'desc')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->index+1); ?></td>
                                        <td><?php echo e($row->name); ?></td>
                                        <td><?php echo e($row->email); ?></td>
                                        <td><?php echo e($row->subject); ?></td>
                                        <td><?php echo e($row->message); ?></td>
                                        <td>
                                            <a class="btn btn-warning" href="<?php echo e(route('backend.blog.edit', $row->id)); ?>">Edit</a>
                                            <a class="btn btn-danger" onclick="return confirm('Are your sure? delete this row.');" href="<?php echo e(route('backend.blog.delete', $row->id)); ?>">Delete</a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div><!-- panel-body -->
                    </div> <!-- panel -->
                </div> <!-- col-->
            </div>

        </div> <!-- container -->
    </div> <!-- content -->
</div> <!-- content-page -->


<?php $__env->stopSection(); ?>





<?php $__env->startPush('meta'); ?>

<?php $__env->stopPush(); ?>




<?php $__env->startPush('styles_top'); ?>

<?php $__env->stopPush(); ?>




<?php $__env->startPush('styles'); ?>
<link href="<?php echo e(asset('/backend/assets/datatables/jquery.dataTables.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopPush(); ?>




<?php $__env->startPush('scripts_head'); ?>

<?php $__env->stopPush(); ?>




<?php $__env->startPush('scripts_top'); ?>

<?php $__env->stopPush(); ?>




<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('/backend/assets/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('/backend/assets/datatables/dataTables.bootstrap.js')); ?>"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.1.2/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.1.2/js/buttons.flash.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
<script type="text/javascript" src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
<script type="text/javascript" src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.1.2/js/buttons.html5.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.1.2/js/buttons.print.min.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
        var datatable = $('#datatable').dataTable();
    });
</script>
<?php $__env->stopPush(); ?>



<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ptl4606q9941/public_html/web.au/resources/views/backend/blog/contact.blade.php ENDPATH**/ ?>